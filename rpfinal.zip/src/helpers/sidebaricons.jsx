import { dashboard, fileicon, partner, report, rewardp } from "./images";

export const menus = [dashboard, fileicon, partner, report];
